"""
memory_manager.py - AI 记忆管理模块
负责：保存对话、读取记忆、压缩摘要、Git 同步
"""
import os
import json
import shutil
from datetime import datetime
from pathlib import Path

try:
    from git import Repo
except ImportError:
    Repo = None

try:
    import yaml
except ImportError:
    yaml = None


class MemoryManager:
    """管理 AI 的记忆系统"""

    def __init__(self, config_path="config/config.yaml"):
        self.config = self._load_config(config_path)
        self.memory_dir = Path("memory")
        self.chat_dir = self.memory_dir / "chat_logs"
        self.summary_dir = self.memory_dir / "summaries"
        self.knowledge_dir = self.memory_dir / "knowledge"
        self.chat_count = 0

        # 确保目录存在
        for d in [self.chat_dir, self.summary_dir, self.knowledge_dir]:
            d.mkdir(parents=True, exist_ok=True)

    def _load_config(self, path):
        """加载配置"""
        if yaml is None:
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            print(f"[警告] 配置文件 {path} 不存在，使用默认配置")
            return {}

    def save_conversation(self, user_input, ai_response, tags=None, model=None):
        """
        保存一次对话到 Markdown 文件，并自动 git commit
        """
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = self.chat_dir / f"{timestamp}.md"

        model_name = model or self.config.get('model', {}).get('name', 'unknown')
        tag_str = ', '.join(tags) if tags else '无'

        content = f"""# 对话记录 {timestamp}

## 用户
{user_input}

## AI
{ai_response}

## 元信息
- 时间: {timestamp}
- 模型: {model_name}
- 标签: {tag_str}
- 类型: 代码问答
"""

        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)

        self.chat_count += 1
        print(f"[记忆] 对话已保存到 {filename}")

        # 自动 git commit
        if self.config.get('memory', {}).get('auto_commit', True):
            self._git_commit(str(filename), f"记忆更新: {timestamp}")

        # 检查是否需要压缩
        compress_after = self.config.get('memory', {}).get('compress_after', 20)
        if self.chat_count >= compress_after:
            self.compress_memories()
            self.chat_count = 0

    def load_recent_memories(self, limit=10):
        """加载最近的对话记录"""
        files = sorted(self.chat_dir.glob("*.md"), reverse=True)
        memories = []
        for f in files[:limit]:
            with open(f, 'r', encoding='utf-8') as file:
                memories.append(file.read())
        return memories

    def load_summaries(self):
        """加载所有摘要"""
        summaries = []
        for f in self.summary_dir.glob("*.md"):
            with open(f, 'r', encoding='utf-8') as file:
                summaries.append(file.read())
        return summaries

    def compress_memories(self):
        """
        把最近的对话压缩成摘要
        注意：这里先保存原始对话，摘要由 AI 在 chat.py 中生成后调用 save_summary()
        """
        files = sorted(self.chat_logs.glob("*.md"), reverse=True)
        if not files:
            return

        # 把旧对话移动到 archive 或直接压缩
        archive_dir = self.chat_dir / "archive"
        archive_dir.mkdir(exist_ok=True)

        # 保留最近 5 条，其余归档
        for f in files[5:]:
            shutil.move(str(f), str(archive_dir / f.name))

        print(f"[记忆] 已归档 {len(files) - 5} 条旧对话")

    def save_summary(self, topic, summary_content):
        """保存 AI 生成的摘要"""
        timestamp = datetime.now().strftime("%Y-%m-%d")
        filename = self.summary_dir / f"{topic}_{timestamp}.md"

        content = f"""# 摘要: {topic}
- 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

{summary_content}
"""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"[记忆] 摘要已保存: {filename}")

        if self.config.get('memory', {}).get('auto_commit', True):
            self._git_commit(str(filename), f"摘要更新: {topic}")

    def save_knowledge(self, query, content, url=""):
        """保存联网搜索的知识"""
        filename = self.knowledge_dir / f"{query[:50].replace(' ', '_')}.md"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        md_content = f"""# 搜索: {query}

## 来源
{url}

## 保存时间
{timestamp}

## 内容
{content}
"""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(md_content)

        if self.config.get('memory', {}).get('auto_commit', True):
            self._git_commit(str(filename), f"知识更新: {query}")

        print(f"[记忆] 知识已保存: {filename}")

    def _git_commit(self, filepath, message):
        """Git commit 单个文件"""
        if Repo is None:
            print("[警告] GitPython 未安装，跳过自动提交")
            return

        try:
            repo = Repo(".")
            repo.index.add([filepath])
            repo.index.commit(message)

            # 自动 push
            if self.config.get('memory', {}).get('auto_push', True):
                origin = repo.remote(name='origin')
                branch = self.config.get('memory', {}).get('branch', 'memory')
                origin.push(branch)

        except Exception as e:
            print(f"[警告] Git 操作失败: {e}")

    def search_memory(self, query, limit=5):
        """在记忆文件中搜索关键词 (简单文本匹配)"""
        results = []
        for md_file in self.memory_dir.rglob("*.md"):
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
                if query.lower() in content.lower():
                    results.append({
                        'file': str(md_file),
                        'content': content[:500],  # 截取前 500 字符
                        'type': md_file.parent.name
                    })
                    if len(results) >= limit:
                        break
        return results


if __name__ == "__main__":
    # 测试
    mm = MemoryManager()
    mm.save_conversation("测试问题", "测试回答", tags=["测试"])
    print("记忆管理模块测试完成")
