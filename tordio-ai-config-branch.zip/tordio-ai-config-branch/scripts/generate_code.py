#!/usr/bin/env python3
"""
generate_code.py - 代码生成模块
基于项目代码检索 + AI 模型生成代码
"""
import os
import re
from pathlib import Path
from datetime import datetime

sys_path = str(Path(__file__).parent)
import sys
sys.path.insert(0, sys_path)

from code_indexer import CodeIndexer
from memory_retriever import MemoryRetriever

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    import yaml
except ImportError:
    yaml = None


class CodeGenerator:
    """代码生成器"""

    def __init__(self, config_path="config/config.yaml"):
        self.config = self._load_config(config_path)
        self.model = self.config.get('model', {}).get('name', 'qwen2.5-coder:1.5b-q4_0')
        self.ollama_host = self.config.get('model', {}).get('host', 'http://localhost:11434')
        self.temperature = self.config.get('model', {}).get('temperature', 0.3)

        self.code_indexer = CodeIndexer(config_path)
        self.memory_retriever = MemoryRetriever(config_path)

    def _load_config(self, path):
        if yaml is None:
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return {}

    def _call_ollama(self, prompt):
        """调用 Ollama 生成代码"""
        if not HAS_REQUESTS:
            return "[错误] requests 未安装"

        try:
            response = requests.post(
                f"{self.ollama_host}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": self.temperature
                    }
                },
                timeout=180
            )
            return response.json().get('response', '').strip()
        except Exception as e:
            return f"[错误] {e}"

    def generate(self, requirement, language=None, context_files=None):
        """
        根据需求生成代码

        Args:
            requirement: 需求描述
            language: 目标语言 (cpp/java/python/js/html/css)
            context_files: 需要参考的项目文件列表

        Returns:
            生成的代码
        """
        # 1. 检索相关代码
        print("[生成] 检索相关代码...")
        code_results = self.code_indexer.search(requirement, top_k=5)

        # 2. 检索相关记忆
        print("[生成] 检索相关记忆...")
        memory_results = self.memory_retriever.hybrid_search(requirement, top_k=3)

        # 3. 读取指定的上下文文件
        context_code = ""
        if context_files:
            for fp in context_files:
                try:
                    with open(fp, 'r', encoding='utf-8') as f:
                        context_code += f"\n### {fp}\n```\n{f.read()[:2000]}\n```\n"
                except Exception:
                    pass

        # 4. 构建 prompt
        prompt = self._build_generation_prompt(
            requirement, language, code_results, memory_results, context_code
        )

        # 5. 生成代码
        print("[生成] 正在生成...\n")
        code = self._call_ollama(prompt)

        return self._extract_code(code)

    def _build_generation_prompt(self, requirement, language, code_results, memory_results, context_code):
        """构建代码生成 prompt"""
        lang_hint = f"目标语言: {language}\n" if language else ""

        prompt = f"""你是 Tordio AI 代码生成器。请基于以下项目代码和记忆，生成符合项目风格的代码。

{lang_hint}
需求: {requirement}

## 项目相关代码
"""

        if code_results:
            for r in code_results:
                prompt += f"\n### {r['filepath']} ({r['start_line']}-{r['end_line']})\n"
                prompt += f"```\n{r['content'][:1000]}\n```\n"
        else:
            prompt += "\n（未找到相关代码）\n"

        if context_code:
            prompt += f"\n## 指定参考文件\n{context_code}\n"

        if memory_results:
            prompt += "\n## 相关记忆\n"
            for r in memory_results:
                prompt += f"\n{r['content'][:400]}\n"

        prompt += """
## 要求
1. 严格遵循项目中已有的代码风格、命名规范、设计模式
2. 复用项目中已有的工具函数、宏、头文件
3. 生成的代码必须完整、可直接编译/运行
4. 包含必要的头文件引用
5. 如果有不确定之处，使用项目中的类似实现作为参考
6. 只输出代码，用 ```语言 代码块 包裹
"""

        return prompt

    def _extract_code(self, text):
        """从 AI 回复中提取代码块"""
        # 尝试匹配代码块
        code_blocks = re.findall(r'```(\w*)\n(.*?)```', text, re.DOTALL)

        if code_blocks:
            # 返回最长的代码块
            longest = max(code_blocks, key=lambda x: len(x[1]))
            return longest[1].strip()

        # 如果没有代码块标记，返回原文
        return text.strip()

    def generate_to_file(self, requirement, output_path, language=None):
        """生成代码并保存到文件"""
        code = self.generate(requirement, language=language)

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            # 添加文件头注释
            header = self._generate_file_header(output_path, requirement)
            f.write(header)
            f.write(code)

        print(f"[生成] 代码已保存到: {output_path}")
        return output_path

    def _generate_file_header(self, filepath, requirement):
        """生成文件头注释"""
        ext = filepath.suffix.lower()

        headers = {
            '.cpp': '//',
            '.h': '//',
            '.hpp': '//',
            '.c': '//',
            '.java': '//',
            '.py': '#',
            '.js': '//',
            '.ts': '//',
            '.html': '',
            '.css': '/*',
        }

        comment = headers.get(ext, '//')
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if ext == '.html':
            return f"<!--\n  自动生成 by Tordio AI\n  时间: {timestamp}\n  需求: {requirement}\n-->\n\n"
        elif ext == '.css':
            return f"/*\n * 自动生成 by Tordio AI\n * 时间: {timestamp}\n * 需求: {requirement}\n */\n\n"
        else:
            return f"{comment} 自动生成 by Tordio AI\n{comment} 时间: {timestamp}\n{comment} 需求: {requirement}\n\n"


if __name__ == "__main__":
    gen = CodeGenerator()

    print("=" * 60)
    print("  Tordio AI - 代码生成器")
    print("=" * 60)

    requirement = input("\n描述你要生成的代码: ")
    language = input("目标语言 (cpp/java/python/js/html/css，留空自动推断): ").strip() or None
    output = input("保存路径 (留空不保存): ").strip()

    if output:
        gen.generate_to_file(requirement, output, language=language)
    else:
        code = gen.generate(requirement, language=language)
        print(f"\n{'=' * 60}")
        print(code)
        print(f"{'=' * 60}")
