#!/bin/bash
# init.sh - Tordio AI 初始化脚本
# 用法: bash scripts/init.sh

set -e

echo "=========================================="
echo "  Tordio AI - 初始化"
echo "=========================================="
echo ""

# 1. 检查 Python
echo "[1/6] 检查 Python..."
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到 python3，请先安装"
    exit 1
fi
echo "  Python: $(python3 --version)"

# 2. 检查 Ollama
echo "[2/6] 检查 Ollama..."
if ! command -v ollama &> /dev/null; then
    echo "  警告: 未找到 Ollama"
    echo "  请安装: https://ollama.com/download"
    echo "  或运行: curl -fsSL https://ollama.com/install.sh | sh"
else
    echo "  Ollama: $(ollama --version 2>/dev/null || echo '已安装')"
fi

# 3. 安装 Python 依赖
echo "[3/6] 安装 Python 依赖..."
pip install -r requirements.txt

# 4. 复制配置文件
echo "[4/6] 复制配置文件..."
if [ ! -f config/config.yaml ]; then
    cp config/config.yaml.example config/config.yaml
    echo "  已创建 config/config.yaml (请编辑后使用)"
else
    echo "  配置文件已存在，跳过"
fi

# 5. 复制环境变量文件
echo "[5/6] 复制环境变量文件..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "  已创建 .env (请填入你的 GitHub Token)"
else
    echo "  .env 已存在，跳过"
fi

# 6. 下载模型 (如果 Ollama 可用)
echo "[6/6] 准备模型..."
if command -v ollama &> /dev/null; then
    echo "  请确保 Ollama 服务已启动: ollama serve"
    echo "  然后拉取模型: ollama pull qwen2.5-coder:1.5b-q4_0"
fi

echo ""
echo "=========================================="
echo "  初始化完成!"
echo "=========================================="
echo ""
echo "下一步:"
echo "  1. 编辑 config/config.yaml 配置你的项目仓库"
echo "  2. 编辑 .env 填入 GitHub Token (私有仓库需要)"
echo "  3. 启动 Ollama: ollama serve"
echo "  4. 拉取模型: ollama pull qwen2.5-coder:1.5b-q4_0"
echo "  5. 构建索引: python scripts/build_index.py"
echo "  6. 开始对话: python scripts/chat.py"
echo ""
