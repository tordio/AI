#!/usr/bin/env python3
"""
project_manager.py - 项目管理模块
管理多个 GitHub 仓库：clone/pull、文件读取、自动同步
"""
import os
import subprocess
import json
from pathlib import Path
from datetime import datetime

try:
    from git import Repo
except ImportError:
    Repo = None

try:
    import requests
except ImportError:
    requests = None

try:
    import yaml
except ImportError:
    yaml = None


class ProjectManager:
    """管理多个项目仓库"""

    def __init__(self, config_path="config/config.yaml"):
        self.config = self._load_config(config_path)
        self.projects = self.config.get('projects', [])
        self.projects_dir = Path("projects")
        self.projects_dir.mkdir(exist_ok=True)

    def _load_config(self, path):
        if yaml is None:
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return {}

    def get_github_token(self):
        """从环境变量获取 GitHub Token"""
        import os
        token_env = self.config.get('github', {}).get('token_env', 'GITHUB_TOKEN')
        return os.environ.get(token_env, '')

    def clone(self, repo_url, local_path, branch="main"):
        """Clone 仓库"""
        local_path = Path(local_path)

        if local_path.exists() and (local_path / ".git").exists():
            print(f"[项目] 已存在: {local_path}")
            return self.pull(local_path)

        local_path.parent.mkdir(parents=True, exist_ok=True)

        # 如果是私有仓库，注入 token
        token = self.get_github_token()
        if token and "github.com" in repo_url:
            # https://<token>@github.com/...  (但不在日志中显示)
            repo_url = repo_url.replace(
                "https://github.com/",
                f"https://{token}@github.com/"
            )

        print(f"[项目] Cloning {repo_url.split('@')[-1] if '@' in repo_url else repo_url} ...")
        try:
            subprocess.run(
                ["git", "clone", "--branch", branch, repo_url, str(local_path)],
                check=True, capture_output=True
            )
            print(f"[项目] Clone 成功: {local_path}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"[错误] Clone 失败: {e.stderr.decode() if e.stderr else e}")
            return False

    def pull(self, local_path):
        """Pull 最新代码"""
        local_path = Path(local_path)
        if not local_path.exists():
            print(f"[错误] 路径不存在: {local_path}")
            return False

        try:
            subprocess.run(
                ["git", "-C", str(local_path), "pull"],
                check=True, capture_output=True
            )
            print(f"[项目] Pull 成功: {local_path}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"[错误] Pull 失败: {e.stderr.decode() if e.stderr else e}")
            return False

    def sync_all(self):
        """同步所有配置的项目"""
        results = []
        for proj in self.projects:
            repo_url = proj.get('repo', '')
            if not repo_url:
                continue

            local_path = proj.get('local_path', f"projects/{proj['name']}")
            branch = proj.get('branches', ['main'])[0]

            if Path(local_path).exists():
                ok = self.pull(local_path)
            else:
                ok = self.clone(repo_url, local_path, branch)

            results.append({
                'name': proj['name'],
                'path': local_path,
                'success': ok
            })

        return results

    def fetch_file_via_api(self, owner, repo, filepath, branch="main"):
        """通过 GitHub API 获取单个文件内容 (不需要 clone 整个仓库)"""
        token = self.get_github_token()
        url = f"https://api.github.com/repos/{owner}/{repo}/contents/{filepath}?ref={branch}"

        headers = {'User-Agent': 'TordioAI/1.0'}
        if token:
            headers['Authorization'] = f"Bearer {token}"

        response = requests.get(url, headers=headers, timeout=10)

        if response.status_code == 200:
            data = response.json()
            import base64
            content = base64.b64decode(data['content']).decode('utf-8')
            return content
        else:
            print(f"[错误] 获取文件失败: {response.status_code} {response.text}")
            return None

    def list_project_files(self, local_path, extensions=None):
        """列出项目中的所有代码文件"""
        local_path = Path(local_path)
        if not local_path.exists():
            return []

        default_exts = {'.cpp', '.h', '.hpp', '.java', '.py', '.js', '.ts',
                        '.html', '.css', '.go', '.rs', '.md'}
        exts = extensions or default_exts

        ignore_dirs = {'node_modules', '.git', 'build', 'dist', 'target',
                       '__pycache__', '.venv', 'vendor', 'third_party'}

        files = []
        for root, dirs, filenames in os.walk(local_path):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]

            for fn in filenames:
                fp = Path(root) / fn
                if fp.suffix.lower() in exts:
                    files.append(str(fp))

        return files

    def read_file(self, filepath):
        """读取文件内容"""
        filepath = Path(filepath)
        if not filepath.exists():
            return None

        encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1']
        for enc in encodings:
            try:
                with open(filepath, 'r', encoding=enc) as f:
                    return f.read()
            except (UnicodeDecodeError, ValueError):
                continue

        # 兜底
        with open(filepath, 'rb') as f:
            return f.read().decode('utf-8', errors='replace')

    def get_file_info(self, filepath):
        """获取文件信息"""
        filepath = Path(filepath)
        if not filepath.exists():
            return None

        return {
            'path': str(filepath),
            'size': filepath.stat().st_size,
            'extension': filepath.suffix,
            'lines': len(self.read_file(filepath).split('\n')),
            'modified': datetime.fromtimestamp(filepath.stat().st_mtime).isoformat()
        }

    def auto_sync_daemon(self, interval=300):
        """自动同步守护进程 (后台运行)"""
        import time
        print(f"[守护] 开始自动同步，间隔 {interval} 秒")
        print("[守护] 按 Ctrl+C 停止")

        try:
            while True:
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] 同步中...")
                results = self.sync_all()
                for r in results:
                    status = "✓" if r['success'] else "✗"
                    print(f"  {status} {r['name']}")

                time.sleep(interval)
        except KeyboardInterrupt:
            print("\n[守护] 停止同步")


if __name__ == "__main__":
    pm = ProjectManager()

    # 同步所有项目
    results = pm.sync_all()
    for r in results:
        print(f"{'✓' if r['success'] else '✗'} {r['name']}: {r['path']}")
