#!/usr/bin/env python3
"""
chat.py - Tordio AI 主对话入口
整合：记忆 + 联网搜索 + 代码检索 + 本地模型
"""
import sys
import os
import json
from pathlib import Path

# 添加 scripts 目录到 path
sys.path.insert(0, str(Path(__file__).parent))

from memory_manager import MemoryManager
from web_search import WebSearch
from code_indexer import CodeIndexer

try:
    import ollama
    import requests
    HAS_OLLAMA = True
except ImportError:
    HAS_OLLAMA = False

try:
    import yaml
except ImportError:
    yaml = None


class TordioAI:
    """Tordio AI 主类"""

    def __init__(self, config_path="config/config.yaml"):
        self.config = self._load_config(config_path)
        self.model = self.config.get('model', {}).get('name', 'qwen2.5-coder:1.5b-q4_0')
        self.temperature = self.config.get('model', {}).get('temperature', 0.3)
        self.ollama_host = self.config.get('model', {}).get('host', 'http://localhost:11434')

        # 初始化各模块
        print("=" * 60)
        print("  Tordio AI - 个人代码助手")
        print("  模型: " + self.model)
        print("=" * 60)

        print("\n[初始化] 加载记忆系统...")
        self.memory = MemoryManager(config_path)

        print("[初始化] 加载搜索模块...")
        self.search = WebSearch(config_path)

        print("[初始化] 加载代码索引...")
        self.code_indexer = CodeIndexer(config_path)

        # 检查索引状态
        stats = self.code_indexer.get_stats()
        if stats.get('status') == 'ready':
            print(f"[索引] 已就绪，共 {stats.get('total_chunks', 0)} 个代码块")
        else:
            print("[索引] 未初始化，请先运行 build_index.py")

        print("\n初始化完成!\n")

    def _load_config(self, path):
        if yaml is None:
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            print(f"[警告] 配置文件 {path} 不存在")
            return {}

    def _call_ollama(self, prompt):
        """调用本地 Ollama 模型"""
        if not HAS_OLLAMA:
            return "[错误] Ollama 未安装，请先安装: pkg install ollama"

        try:
            response = requests.post(
                f"{self.ollama_host}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": self.temperature
                    }
                },
                timeout=120
            )
            data = response.json()
            return data.get('response', '').strip()
        except Exception as e:
            return f"[错误] 无法连接 Ollama ({self.ollama_host}): {e}\n请确认 Ollama 已启动: ollama serve"

    def _retrieve_context(self, query):
        """检索相关上下文：代码 + 记忆"""
        context_parts = []

        # 1. 代码检索
        code_results = self.code_indexer.search(query, top_k=5)
        if code_results:
            context_parts.append("## 相关代码")
            for r in code_results:
                context_parts.append(
                    f"\n### {r['filepath']} ({r['start_line']}-{r['end_line']})\n"
                    f"```\n{r['content'][:800]}\n```\n"
                )

        # 2. 记忆检索 (关键词匹配)
        memory_results = self.memory.search_memory(query, limit=3)
        if memory_results:
            context_parts.append("\n## 相关记忆")
            for r in memory_results:
                context_parts.append(f"\n---\n{r['content'][:400]}\n")

        return '\n'.join(context_parts)

    def _build_prompt(self, query, context, search_results=None):
        """构建完整 prompt"""
        prompt = f"""你是 Tordio AI，一个专注于代码和计算机领域的个人助手。
你的主人是 tordio。你擅长 C++、Java、Python、JavaScript、HTML/CSS。

以下是与用户问题相关的项目代码和历史记忆，请基于这些内容回答：

{context}
"""

        if search_results:
            prompt += "\n## 联网搜索结果\n"
            for r in search_results:
                prompt += f"\n### {r['title']}\n{r['content'][:500]}\n"

        prompt += f"""
---

用户问题: {query}

请基于你的知识和以上参考资料，给出专业、准确的回答。如果涉及代码，请给出完整可运行的代码。
如果不确定，请坦诚说明。
"""

        return prompt

    def chat(self, user_input):
        """处理一次对话"""

        # 1. 判断是否联网搜索
        search_results = None
        if self.search.is_search_query(user_input):
            print("[搜索] 正在联网搜索...")
            query = user_input
            for kw in ['搜索', '查一下', '查找', '搜一下', 'search']:
                query = query.replace(kw, '').strip()
            search_results = self.search.search(query)
            print(f"[搜索] 找到 {len(search_results)} 条结果")

        # 2. 检索上下文
        print("[检索] 正在检索相关代码和记忆...")
        context = self._retrieve_context(user_input)

        # 3. 构建 prompt
        prompt = self._build_prompt(user_input, context, search_results)

        # 4. 调用模型
        print("[模型] 正在生成回复...\n")
        response = self._call_ollama(prompt)

        # 5. 保存对话
        tags = self._extract_tags(user_input, search_results)
        self.memory.save_conversation(user_input, response, tags=tags, model=self.model)

        return response

    def _extract_tags(self, user_input, search_results=None):
        """从对话中提取标签"""
        tags = []
        keywords = {
            '代码': ['代码', 'code', '函数', 'class', 'function'],
            '搜索': ['搜索', '查一下', 'search'],
            'C++': ['.cpp', '.h', 'c++', 'cpp'],
            'Java': ['java', '.java'],
            'Python': ['python', '.py'],
            'JS': ['javascript', '.js', 'js'],
            'HTML': ['.html', '.css', 'html', '网页'],
        }

        for tag, kws in keywords.items():
            if any(kw in user_input.lower() for kw in kws):
                tags.append(tag)

        if search_results:
            tags.append('联网搜索')

        return tags if tags else ['对话']

    def interactive(self):
        """交互式对话"""
        print("开始对话吧! (输入 'exit' 或 'quit' 退出, 'search:关键词' 联网搜索)\n")

        while True:
            try:
                user_input = input("你: ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\n\n再见!")
                break

            if not user_input:
                continue

            if user_input.lower() in ['exit', 'quit', '退出', ':q']:
                print("再见!")
                break

            if user_input.lower() in ['help', '帮助']:
                self._show_help()
                continue

            # 执行对话
            response = self.chat(user_input)
            print(f"\nAI: {response}\n")
            print("-" * 60 + "\n")

    def _show_help(self):
        """显示帮助"""
        help_text = """
命令:
  直接输入问题       → AI 基于代码库和记忆回答
  搜索 xxx          → 联网搜索 xxx 并保存结果
  help              → 显示此帮助
  exit/quit         → 退出

示例:
  你: AuthService 的 token 刷新逻辑在哪?
  你: 搜索 c++20 coroutine 异步编程
  你: 按 UserService 的风格写一个 DeviceService
  你: 帮我写一个 WebSocket 服务器
"""
        print(help_text)


if __name__ == "__main__":
    ai = TordioAI()
    ai.interactive()
