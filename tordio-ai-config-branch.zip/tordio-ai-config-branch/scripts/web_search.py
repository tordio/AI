"""
web_search.py - 联网搜索模块
通过 Python 脚本搜索内容并自动保存到记忆库
"""
import json
import urllib.parse
import urllib.request
from pathlib import Path

try:
    from bs4 import BeautifulSoup
    HAS_BS4 = True
except ImportError:
    HAS_BS4 = False

from memory_manager import MemoryManager


class WebSearch:
    """联网搜索并自动保存"""

    def __init__(self, config_path="config/config.yaml"):
        self.mm = MemoryManager(config_path)
        self.config = self.mm.config
        self.enabled = self.config.get('search', {}).get('enabled', True)
        self.max_results = self.config.get('search', {}).get('max_results', 5)
        self.auto_save = self.config.get('search', {}).get('auto_save', True)

    def search(self, query):
        """
        执行搜索，返回结果列表
        使用 DuckDuckGo 的公开接口 (无需 API key)
        """
        if not self.enabled:
            return []

        results = []

        # 方法1: DuckDuckGo Instant Answer API
        try:
            ddg_results = self._duckduckgo_search(query)
            results.extend(ddg_results)
        except Exception as e:
            print(f"[搜索] DuckDuckGo 失败: {e}")

        # 如果 DuckDuckGo 结果不够，尝试其他方法
        if len(results) < self.max_results:
            try:
                wiki_results = self._wikipedia_search(query)
                results.extend(wiki_results)
            except Exception as e:
                print(f"[搜索] Wikipedia 失败: {e}")

        # 限制结果数量
        results = results[:self.max_results]

        # 自动保存
        if self.auto_save and results:
            self._save_results(query, results)

        return results

    def _duckduckgo_search(self, query):
        """DuckDuckGo 搜索"""
        url = f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}&format=json&no_html=1&skip_disambig=1"

        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; TordioAI/1.0)'
        })

        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        results = []

        # 提取 AbstractText
        if data.get('AbstractText'):
            results.append({
                'title': data.get('AbstractSource', 'DuckDuckGo'),
                'content': data['AbstractText'],
                'url': data.get('AbstractURL', '')
            })

        # 提取 RelatedTopics
        for topic in data.get('RelatedTopics', [])[:5]:
            if 'Text' in topic:
                results.append({
                    'title': topic.get('Text', '')[:100],
                    'content': topic.get('Text', ''),
                    'url': topic.get('FirstURL', '')
                })

        return results

    def _wikipedia_search(self, query):
        """Wikipedia 搜索 (兜底方案)"""
        url = f"https://zh.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(query)}"

        req = urllib.request.Request(url, headers={
            'User-Agent': 'TordioAI/1.0'
        })

        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        results = []
        if data.get('extract'):
            results.append({
                'title': data.get('title', query),
                'content': data['extract'],
                'url': data.get('content_urls', {}).get('desktop', {}).get('page', '')
            })

        return results

    def _save_results(self, query, results):
        """保存搜索结果到记忆库"""
        save_dir = Path(self.config.get('search', {}).get('save_dir', 'memory/knowledge'))
        save_dir.mkdir(parents=True, exist_ok=True)

        filename = save_dir / f"{query[:50].replace(' ', '_')}.md"
        timestamp = __import__('datetime').datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        content = f"# 搜索: {query}\n\n"
        content += f"**保存时间**: {timestamp}\n\n"

        for i, r in enumerate(results, 1):
            content += f"## {i}. {r['title']}\n\n"
            content += f"{r['content']}\n\n"
            if r.get('url'):
                content += f"**来源**: {r['url']}\n\n"
            content += "---\n\n"

        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)

        # Git commit
        self.mm._git_commit(str(filename), f"知识更新: {query}")
        print(f"[搜索] 已保存 {len(results)} 条结果到 {filename}")

    def is_search_query(self, text):
        """判断是否是搜索请求"""
        search_keywords = [
            '搜索', '查一下', '查找', '搜一下', 'search',
            '什么是', '怎么', '如何', '为什么', 'what is',
            'how to', 'how do'
        ]
        text_lower = text.lower()
        return any(kw in text_lower for kw in search_keywords)


if __name__ == "__main__":
    ws = WebSearch()
    results = ws.search("C++ std::shared_ptr 线程安全")
    for r in results:
        print(f"- {r['title']}: {r['content'][:100]}...")
