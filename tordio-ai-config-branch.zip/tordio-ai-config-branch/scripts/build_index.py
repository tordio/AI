#!/usr/bin/env python3
"""
build_index.py - 构建/重建索引
扫描项目代码 → 切分 → 向量化 → 存入 ChromaDB
"""
import sys
import os
import subprocess
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from code_indexer import CodeIndexer
try:
    import yaml
except ImportError:
    yaml = None


def load_config(path="config/config.yaml"):
    if yaml is None:
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        return {}


def clone_repo(repo_url, local_path, branch="main"):
    """Clone 或 pull 项目仓库"""
    local_path = Path(local_path)

    if local_path.exists() and (local_path / ".git").exists():
        print(f"[同步] Pulling {local_path}...")
        subprocess.run(["git", "-C", str(local_path), "pull"], check=True)
    else:
        local_path.parent.mkdir(parents=True, exist_ok=True)
        print(f"[同步] Cloning {repo_url} -> {local_path}...")
        subprocess.run([
            "git", "clone", "--branch", branch, repo_url, str(local_path)
        ], check=True)


def main():
    config = load_config()

    print("=" * 60)
    print("  Tordio AI - 索引构建工具")
    print("=" * 60)

    # 同步所有配置的项目
    projects = config.get('projects', [])
    if not projects:
        print("\n[提示] 没有配置项目，请在 config/config.yaml 中添加 projects")
        print("示例:")
        print('  projects:')
        print('    - name: "my-project"')
        print('      repo: "https://github.com/tordio/my-project.git"')
        print('      local_path: "projects/my-project"')
        print('      file_types: [".cpp", ".h", ".py", ".js"]')
        sys.exit(0)

    all_file_types = set()
    for proj in projects:
        # 同步仓库
        repo_url = proj.get('repo', '')
        if repo_url:
            clone_repo(repo_url, proj['local_path'], proj.get('branches', ['main'])[0])
        else:
            print(f"[提示] {proj['name']} 未配置 repo，跳过同步")

        # 收集文件类型
        for ft in proj.get('file_types', []):
            all_file_types.add(ft)

    # 构建索引
    print("\n[索引] 开始构建...")
    indexer = CodeIndexer()

    for proj in projects:
        local_path = proj['local_path']
        file_types = set(proj.get('file_types', []))
        print(f"\n[索引] 处理项目: {proj['name']} ({local_path})")
        indexer.index_directory(local_path, file_types=file_types)

    # 输出统计
    stats = indexer.get_stats()
    print(f"\n{'=' * 60}")
    print(f"  索引构建完成!")
    print(f"  总代码块: {stats.get('total_chunks', 0)}")
    print(f"  索引位置: {stats.get('index_path', '')}")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
