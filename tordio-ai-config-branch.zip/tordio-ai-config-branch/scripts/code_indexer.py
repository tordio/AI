"""
code_indexer.py - 代码索引模块
扫描项目代码，切分，向量化，存入 ChromaDB
"""
import os
import re
from pathlib import Path
from datetime import datetime

try:
    import chromadb
    from chromadb.config import Settings
    HAS_CHROMA = True
except ImportError:
    HAS_CHROMA = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False

try:
    import yaml
except ImportError:
    yaml = None


# 支持的文件类型
CODE_EXTENSIONS = {
    '.cpp', '.cc', '.cxx', '.c', '.h', '.hpp', '.hxx',
    '.java', '.py', '.js', '.ts', '.jsx', '.tsx',
    '.html', '.css', '.scss', '.less',
    '.go', '.rs', '.rb', '.php', '.swift', '.kt',
    '.md', '.txt', '.json', '.yaml', '.yml'
}

# 需要忽略的目录
IGNORE_DIRS = {
    'node_modules', '.git', '.svn', 'build', 'dist', 'target',
    'bin', 'obj', '.gradle', '.mvn', '__pycache__', '.venv',
    'venv', 'env', '.idea', '.vscode', 'third_party', 'vendor'
}


class CodeIndexer:
    """代码索引器"""

    def __init__(self, config_path="config/config.yaml"):
        self.config = self._load_config(config_path)
        self.index_config = self.config.get('index', {})
        self.chunk_size = self.index_config.get('chunk_size', 800)
        self.chunk_overlap = self.index_config.get('chunk_overlap', 100)

        # ChromaDB 客户端
        self.chroma_path = self.index_config.get('path', 'index/code_db')
        Path(self.chroma_path).mkdir(parents=True, exist_ok=True)

        self.client = None
        self.collection = None

        if HAS_CHROMA:
            self.client = chromadb.PersistentClient(
                path=self.chroma_path,
                settings=Settings(anonymized_telemetry=False)
            )
            self.collection = self.client.get_or_create_collection(
                name="code_index",
                metadata={"created": datetime.now().isoformat()}
            )

        # Embedding 模型 (延迟加载)
        self.embedding_model = None

    def _load_config(self, path):
        if yaml is None:
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return {}

    def _get_embedding_model(self):
        """延迟加载 embedding 模型"""
        if self.embedding_model is None and HAS_SENTENCE_TRANSFORMERS:
            model_name = self.index_config.get(
                'embedding_model',
                'all-MiniLM-L6-v2'
            )
            print(f"[索引] 加载 embedding 模型: {model_name}")
            self.embedding_model = SentenceTransformer(model_name)
        return self.embedding_model

    def should_ignore(self, path):
        """判断是否应该忽略该路径"""
        parts = Path(path).parts
        return any(ignore in parts for ignore in IGNORE_DIRS)

    def is_code_file(self, filepath):
        """判断是否是代码文件"""
        ext = Path(filepath).suffix.lower()
        return ext in CODE_EXTENSIONS

    def read_file(self, filepath):
        """读取文件内容，处理编码问题"""
        encodings = ['utf-8', 'gbk', 'latin-1', 'gb2312']
        for enc in encodings:
            try:
                with open(filepath, 'r', encoding=enc) as f:
                    return f.read()
            except (UnicodeDecodeError, ValueError):
                continue
        # 最后兜底
        with open(filepath, 'rb') as f:
            return f.read().decode('utf-8', errors='replace')

    def chunk_code(self, content, filepath):
        """
        智能切分代码
        优先按函数/类边界切分，其次按行数切分
        """
        ext = Path(filepath).suffix.lower()
        chunks = []

        # C/C++/Java/JS 等用大括号切分
        if ext in {'.cpp', '.cc', '.cxx', '.c', '.h', '.hpp', '.java', '.js', '.ts'}:
            chunks = self._chunk_by_braces(content, filepath)
        # Python 按缩进/函数切分
        elif ext == '.py':
            chunks = self._chunk_by_python(content, filepath)
        # 其他按行切分
        else:
            chunks = self._chunk_by_lines(content, filepath)

        # 如果切分结果太少，直接按固定大小切
        if not chunks:
            chunks = self._chunk_by_size(content, filepath)

        return chunks

    def _chunk_by_braces(self, content, filepath):
        """按大括号匹配切分 (C/C++/Java/JS)"""
        chunks = []
        lines = content.split('\n')
        current_chunk = []
        brace_depth = 0
        chunk_start = 0

        for i, line in enumerate(lines):
            current_chunk.append(line)
            brace_depth += line.count('{') - line.count('}')

            # 当一个完整的块结束时 (brace_depth 回到 0 且 chunk 够大)
            chunk_text = '\n'.join(current_chunk)
            if brace_depth == 0 and len(chunk_text) > self.chunk_size * 2:
                chunks.append({
                    'content': chunk_text,
                    'filepath': str(filepath),
                    'start_line': chunk_start,
                    'end_line': i
                })
                current_chunk = []
                chunk_start = i + 1

        # 剩余部分
        if current_chunk:
            chunk_text = '\n'.join(current_chunk)
            if chunk_text.strip():
                chunks.append({
                    'content': chunk_text,
                    'filepath': str(filepath),
                    'start_line': chunk_start,
                    'end_line': len(lines) - 1
                })

        return chunks

    def _chunk_by_python(self, content, filepath):
        """按 Python 函数和类切分"""
        chunks = []
        lines = content.split('\n')
        current_chunk = []
        indent_level = 0
        chunk_start = 0

        for i, line in enumerate(lines):
            stripped = line.strip()

            # 检测函数或类定义
            is_def = stripped.startswith('def ') or stripped.startswith('class ')

            if is_def and current_chunk:
                # 保存上一个块
                chunk_text = '\n'.join(current_chunk)
                if chunk_text.strip():
                    chunks.append({
                        'content': chunk_text,
                        'filepath': str(filepath),
                        'start_line': chunk_start,
                        'end_line': i - 1
                    })
                current_chunk = []
                chunk_start = i

            current_chunk.append(line)

        # 剩余部分
        if current_chunk:
            chunk_text = '\n'.join(current_chunk)
            if chunk_text.strip():
                chunks.append({
                    'content': chunk_text,
                    'filepath': str(filepath),
                    'start_line': chunk_start,
                    'end_line': len(lines) - 1
                })

        return chunks

    def _chunk_by_lines(self, content, filepath):
        """按行数切分"""
        lines = content.split('\n')
        chunks = []
        chunk = []
        start_line = 0

        for i, line in enumerate(lines):
            chunk.append(line)
            if len('\n'.join(chunk)) >= self.chunk_size:
                chunks.append({
                    'content': '\n'.join(chunk),
                    'filepath': str(filepath),
                    'start_line': start_line,
                    'end_line': i
                })
                # 保留 overlap
                overlap_lines = max(0, int(len(chunk) * self.chunk_overlap / self.chunk_size))
                chunk = chunk[-overlap_lines:] if overlap_lines > 0 else []
                start_line = i - len(chunk) + 1

        if chunk:
            chunks.append({
                'content': '\n'.join(chunk),
                'filepath': str(filepath),
                'start_line': start_line,
                'end_line': len(lines) - 1
            })

        return chunks

    def _chunk_by_size(self, content, filepath):
        """按固定字符大小切分"""
        chunks = []
        lines = content.split('\n')
        current = []
        total_len = 0
        start_line = 0

        for i, line in enumerate(lines):
            current.append(line)
            total_len += len(line)

            if total_len >= self.chunk_size:
                chunks.append({
                    'content': '\n'.join(current),
                    'filepath': str(filepath),
                    'start_line': start_line,
                    'end_line': i
                })
                overlap = int(self.chunk_overlap / 2)
                current = current[-overlap:] if overlap > 0 else []
                total_len = sum(len(l) for l in current)
                start_line = i - len(current) + 1

        if current:
            chunks.append({
                'content': '\n'.join(current),
                'filepath': str(filepath),
                'start_line': start_line,
                'end_line': len(lines) - 1
            })

        return chunks

    def index_directory(self, directory, file_types=None):
        """
        索引整个目录
        """
        if not HAS_CHROMA:
            print("[错误] ChromaDB 未安装，无法建索引")
            return

        directory = Path(directory)
        if not directory.exists():
            print(f"[错误] 目录不存在: {directory}")
            return

        print(f"[索引] 开始扫描: {directory}")

        all_files = []
        for root, dirs, files in os.walk(directory):
            # 过滤忽略目录
            dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]

            for file in files:
                filepath = Path(root) / file
                if self.is_code_file(filepath):
                    if file_types is None or filepath.suffix.lower() in file_types:
                        all_files.append(filepath)

        print(f"[索引] 找到 {len(all_files)} 个代码文件")

        all_chunks = []
        for filepath in all_files:
            try:
                content = self.read_file(filepath)
                chunks = self.chunk_code(content, filepath)
                all_chunks.extend(chunks)
            except Exception as e:
                print(f"[警告] 处理文件失败 {filepath}: {e}")

        print(f"[索引] 生成 {len(all_chunks)} 个代码块")

        # 向量化并存入 ChromaDB
        if all_chunks:
            self._store_chunks(all_chunks)

        print(f"[索引] 完成! 索引保存在: {self.chroma_path}")

    def _store_chunks(self, chunks):
        """将代码块存入向量数据库"""
        model = self._get_embedding_model()
        if model is None:
            print("[警告] Embedding 模型不可用，跳过向量化")
            return

        batch_size = 32
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]

            # 生成 embeddings
            texts = [c['content'][:1000] for c in batch]  # 限制长度
            embeddings = model.encode(texts).tolist()

            # 准备数据
            ids = [f"chunk_{i + j}" for j in range(len(batch))]
            metadatas = [
                {
                    'filepath': c['filepath'],
                    'start_line': c['start_line'],
                    'end_line': c['end_line']
                }
                for c in batch
            ]

            # 存入 ChromaDB
            self.collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=texts,
                metadatas=metadatas
            )

            print(f"[索引] 已存储 {min(i + batch_size, len(chunks))}/{len(chunks)} 个块")

    def search(self, query, top_k=5):
        """
        语义搜索代码
        """
        if not HAS_CHROMA or self.collection is None:
            print("[错误] 索引未初始化")
            return []

        model = self._get_embedding_model()
        if model is None:
            return []

        query_embedding = model.encode([query]).tolist()[0]

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k
        )

        formatted = []
        if results and results.get('documents'):
            for i, doc in enumerate(results['documents'][0]):
                metadata = results['metadatas'][0][i] if results.get('metadatas') else {}
                formatted.append({
                    'content': doc,
                    'filepath': metadata.get('filepath', ''),
                    'start_line': metadata.get('start_line', 0),
                    'end_line': metadata.get('end_line', 0),
                    'distance': results['distances'][0][i] if results.get('distances') else 0
                })

        return formatted

    def get_stats(self):
        """获取索引统计信息"""
        if not HAS_CHROMA or self.collection is None:
            return {"status": "not_initialized"}

        count = self.collection.count()
        return {
            "status": "ready",
            "total_chunks": count,
            "index_path": self.chroma_path
        }


if __name__ == "__main__":
    indexer = CodeIndexer()
    # 索引 projects 目录
    indexer.index_directory("projects")
    # 搜索测试
    results = indexer.search("token refresh logic")
    for r in results:
        print(f"- {r['filepath']}:{r['start_line']}-{r['end_line']}")
