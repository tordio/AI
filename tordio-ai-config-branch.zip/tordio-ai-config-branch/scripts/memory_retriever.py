#!/usr/bin/env python3
"""
memory_retriever.py - 记忆检索模块
从 memory 分支检索相关记忆，支持语义搜索和关键词匹配
"""
import os
from pathlib import Path
from datetime import datetime

try:
    import chromadb
    from chromadb.config import Settings
    HAS_CHROMA = True
except ImportError:
    HAS_CHROMA = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_ST = True
except ImportError:
    HAS_ST = False

try:
    import yaml
except ImportError:
    yaml = None


class MemoryRetriever:
    """记忆检索器 - 从 memory 分支中检索相关内容"""

    def __init__(self, config_path="config/config.yaml"):
        self.config = self._load_config(config_path)
        self.memory_dir = Path("memory")
        self.max_tokens = self.config.get('memory', {}).get('max_memory_tokens', 2000)

        # ChromaDB for semantic search
        self.chroma_path = "index/memory_db"
        Path(self.chroma_path).mkdir(parents=True, exist_ok=True)

        self.client = None
        self.collection = None
        self.embedding_model = None

        if HAS_CHROMA:
            self.client = chromadb.PersistentClient(
                path=self.chroma_path,
                settings=Settings(anonymized_telemetry=False)
            )
            self.collection = self.client.get_or_create_collection(
                name="memory_index",
                metadata={"description": "AI 记忆向量索引"}
            )

    def _load_config(self, path):
        if yaml is None:
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return {}

    def _get_embedding_model(self):
        if self.embedding_model is None and HAS_ST:
            model_name = self.config.get('index', {}).get(
                'embedding_model', 'all-MiniLM-L6-v2'
            )
            self.embedding_model = SentenceTransformer(model_name)
        return self.embedding_model

    def index_all_memories(self):
        """将所有 Markdown 记忆文件索引到向量数据库"""
        if not HAS_CHROMA:
            print("[错误] ChromaDB 未安装")
            return

        model = self._get_embedding_model()
        if model is None:
            print("[错误] Embedding 模型不可用")
            return

        # 收集所有 md 文件
        all_files = []
        for subdir in ['chat_logs', 'summaries', 'knowledge']:
            dir_path = self.memory_dir / subdir
            if dir_path.exists():
                all_files.extend(dir_path.glob("*.md"))

        if not all_files:
            print("[索引] 没有找到记忆文件")
            return

        print(f"[索引] 处理 {len(all_files)} 个记忆文件")

        # 清空旧索引
        try:
            self.client.delete_collection("memory_index")
            self.collection = self.client.get_or_create_collection(
                name="memory_index",
                metadata={"description": "AI 记忆向量索引"}
            )
        except Exception:
            pass

        # 切分并索引
        all_chunks = []
        for filepath in all_files:
            content = self._read_file(filepath)
            if not content.strip():
                continue

            # 按段落切分
            chunks = self._split_content(content, str(filepath))
            all_chunks.extend(chunks)

        if not all_chunks:
            return

        # 批量存储
        batch_size = 32
        for i in range(0, len(all_chunks), batch_size):
            batch = all_chunks[i:i + batch_size]
            texts = [c['content'][:1000] for c in batch]
            embeddings = model.encode(texts).tolist()

            ids = [f"mem_{i + j}" for j in range(len(batch))]
            metadatas = [
                {
                    'filepath': c['filepath'],
                    'chunk_index': c.get('chunk_index', 0),
                    'category': c.get('category', 'chat')
                }
                for c in batch
            ]

            self.collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=texts,
                metadatas=metadatas
            )

        print(f"[索引] 完成! 共索引 {len(all_chunks)} 个记忆片段")

    def _read_file(self, filepath):
        """读取文件，处理编码"""
        encodings = ['utf-8', 'gbk', 'latin-1']
        for enc in encodings:
            try:
                with open(filepath, 'r', encoding=enc) as f:
                    return f.read()
            except (UnicodeDecodeError, ValueError):
                continue
        return ""

    def _split_content(self, content, filepath):
        """将 Markdown 内容按段落切分"""
        # 判断类别
        category = 'chat'
        if 'summaries' in filepath:
            category = 'summary'
        elif 'knowledge' in filepath:
            category = 'knowledge'

        # 按段落切分
        paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]

        chunks = []
        current_chunk = []
        current_size = 0
        chunk_index = 0

        for para in paragraphs:
            para_size = len(para)
            if current_size + para_size > 800 and current_chunk:
                chunks.append({
                    'content': '\n\n'.join(current_chunk),
                    'filepath': filepath,
                    'chunk_index': chunk_index,
                    'category': category
                })
                current_chunk = [para]
                current_size = para_size
                chunk_index += 1
            else:
                current_chunk.append(para)
                current_size += para_size

        if current_chunk:
            chunks.append({
                'content': '\n\n'.join(current_chunk),
                'filepath': filepath,
                'chunk_index': chunk_index,
                'category': category
            })

        return chunks

    def semantic_search(self, query, top_k=5):
        """语义搜索记忆"""
        if not HAS_CHROMA or self.collection is None:
            return self.keyword_search(query, top_k)

        model = self._get_embedding_model()
        if model is None:
            return self.keyword_search(query, top_k)

        query_embedding = model.encode([query]).tolist()[0]

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k
        )

        formatted = []
        if results and results.get('documents'):
            for i, doc in enumerate(results['documents'][0]):
                metadata = results['metadatas'][0][i] if results.get('metadatas') else {}
                formatted.append({
                    'content': doc,
                    'filepath': metadata.get('filepath', ''),
                    'category': metadata.get('category', 'chat'),
                    'distance': results['distances'][0][i] if results.get('distances') else 0
                })

        return formatted

    def keyword_search(self, query, top_k=5):
        """关键词搜索 (ChromaDB 不可用时的兜底)"""
        results = []
        query_lower = query.lower()
        keywords = query_lower.split()

        for md_file in self.memory_dir.rglob("*.md"):
            content = self._read_file(md_file)
            content_lower = content.lower()

            # 计算匹配度
            match_count = sum(1 for kw in keywords if kw in content_lower)
            if match_count > 0:
                # 找到最相关的段落
                paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
                best_para = ""
                best_count = 0
                for para in paragraphs:
                    para_lower = para.lower()
                    para_count = sum(1 for kw in keywords if kw in para_lower)
                    if para_count > best_count:
                        best_count = para_count
                        best_para = para[:500]

                results.append({
                    'content': best_para,
                    'filepath': str(md_file),
                    'category': 'chat',
                    'match_count': match_count
                })

        # 按匹配度排序
        results.sort(key=lambda x: x.get('match_count', 0), reverse=True)
        return results[:top_k]

    def hybrid_search(self, query, top_k=5):
        """混合搜索：语义 + 关键词"""
        semantic_results = self.semantic_search(query, top_k=top_k)
        keyword_results = self.keyword_search(query, top_k=top_k)

        # 合并去重
        seen = set()
        combined = []

        for r in semantic_results:
            filepath = r['filepath']
            if filepath not in seen:
                seen.add(filepath)
                combined.append(r)

        for r in keyword_results:
            filepath = r['filepath']
            if filepath not in seen:
                seen.add(filepath)
                combined.append(r)

        return combined[:top_k]

    def get_recent(self, limit=10):
        """获取最近的对话记录"""
        chat_dir = self.memory_dir / "chat_logs"
        if not chat_dir.exists():
            return []

        files = sorted(chat_dir.glob("*.md"), reverse=True)
        recent = []
        for f in files[:limit]:
            content = self._read_file(f)
            recent.append({
                'filepath': str(f),
                'content': content[:500]
            })

        return recent

    def format_for_prompt(self, memories):
        """将检索结果格式化为 prompt 上下文"""
        if not memories:
            return "（无相关记忆）"

        parts = []
        total_len = 0

        for i, mem in enumerate(memories, 1):
            content = mem['content']
            # 限制每个记忆的长度
            if total_len + len(content) > self.max_tokens * 4:  # 粗略 token 估算
                break

            parts.append(f"### 记忆 {i} ({mem['category']})\n{content[:600]}")
            total_len += len(content)

        return '\n\n'.join(parts)


if __name__ == "__main__":
    retriever = MemoryRetriever()

    # 先索引
    print("索引记忆...")
    retriever.index_all_memories()

    # 搜索测试
    query = input("搜索记忆: ")
    results = retriever.hybrid_search(query, top_k=5)

    print(f"\n找到 {len(results)} 条相关记忆:\n")
    for r in results:
        print(f"- [{r['category']}] {r['filepath']}")
        print(f"  {r['content'][:150]}...")
        print()
