"""
rebuild_index.py - 向量索引重建脚本
扫描 projects/ 与 memory/knowledge/，切分后写入向量数据库
"""
import os
import glob

try:
    import chromadb
    from chromadb.config import Settings
    HAS_CHROMA = True
except ImportError:
    HAS_CHROMA = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_ST = True
except ImportError:
    HAS_ST = False

INDEX_PATH = "data"
PROJECTS_DIR = "projects"
MEMORY_DIR = "memory/knowledge"
CHUNK_SIZE = 512
CHUNK_OVERLAP = 50


def chunk_text(text, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    """把文本按字符切分为带重叠的块"""
    chunks = []
    if not text:
        return chunks
    step = chunk_size - overlap
    for i in range(0, len(text), step):
        chunk = text[i:i + chunk_size]
        if len(chunk) >= 20:
            chunks.append(chunk)
    return chunks


def collect_files(root, extensions):
    """递归收集指定扩展名的文件"""
    files = []
    for ext in extensions:
        pattern = os.path.join(root, "**", ext)
        files.extend(glob.glob(pattern, recursive=True))
    return files


def build():
    if not HAS_CHROMA:
        print("[错误] chromadb 未安装，请先运行: pip install chromadb sentence-transformers")
        return

    os.makedirs(INDEX_PATH, exist_ok=True)
    client = chromadb.PersistentClient(path=INDEX_PATH)
    collection = client.get_or_create_collection("ai_code_index")

    # 清空旧数据
    try:
        existing = collection.get()
        if existing and existing.get("ids"):
            collection.delete(ids=existing["ids"])
    except Exception:
        pass

    doc_id = 0

    # 1. 索引项目代码
    print("[索引] 扫描项目代码...")
    code_exts = ["*.cpp", "*.h", "*.hpp", "*.java", "*.py", "*.js", "*.ts", "*.html", "*.css", "*.md"]
    code_files = collect_files(PROJECTS_DIR, code_exts)
    print(f"  找到 {len(code_files)} 个代码文件")

    for filepath in code_files:
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            for chunk in chunk_text(content)[:15]:  # 每个文件最多 15 块
                collection.add(
                    documents=[chunk],
                    ids=[f"code_{doc_id}"],
                    metadatas=[{"source": filepath, "type": "code"}]
                )
                doc_id += 1
        except Exception:
            continue

    # 2. 索引记忆知识
    print("[索引] 扫描记忆知识...")
    md_files = collect_files(MEMORY_DIR, ["*.md"])
    print(f"  找到 {len(md_files)} 个知识文件")

    for filepath in md_files:
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            for chunk in chunk_text(content):
                collection.add(
                    documents=[chunk],
                    ids=[f"mem_{doc_id}"],
                    metadatas=[{"source": filepath, "type": "memory"}]
                )
                doc_id += 1
        except Exception:
            continue

    print(f"[完成] 共写入 {doc_id} 个文档片段")
    print(f"       存储位置: {os.path.abspath(INDEX_PATH)}")


def query(text, top_k=5):
    """检索索引"""
    if not HAS_CHROMA:
        print("[错误] chromadb 未安装")
        return

    client = chromadb.PersistentClient(path=INDEX_PATH)
    collection = client.get_or_create_collection("ai_code_index")

    if HAS_ST:
        model = SentenceTransformer("all-MiniLM-L6-v2")
        embedding = model.encode([text]).tolist()[0]
        results = collection.query(query_embeddings=[embedding], n_results=top_k)
    else:
        results = collection.query(query_texts=[text], n_results=top_k)

    for i, doc in enumerate(results["documents"][0]):
        print(f"\n--- 结果 {i+1} ---")
        print(doc[:300])


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "query":
        query(sys.argv[2] if len(sys.argv) > 2 else "")
    else:
        build()
