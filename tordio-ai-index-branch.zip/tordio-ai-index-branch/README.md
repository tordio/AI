# Index Branch

存放 AI Code Assistant 的向量索引逻辑与本地数据。

## 说明

- `rebuild_index.py` — 一键重建向量索引（扫描 `projects/` 与 `memory/knowledge/`）
- `data/` — 本地持久化目录（Chromadb / Faiss 数据），不提交大文件
- 实际索引在 `init.sh` 或手动运行脚本后生成

## 运行

```bash
# 重建索引
python rebuild_index.py

# 检索测试
python rebuild_index.py query "token 刷新逻辑"
```

## 依赖

```bash
pip install chromadb sentence-transformers
```
