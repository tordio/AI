# 摘要: AuthService 模块

- 生成时间: 2026-11-08 12:00:00

## 核心结论

- Token 刷新逻辑在 `token_manager.cpp:142` 的 `refreshToken()`
- 刷新由 `AuthMiddleware` 在 401 响应时触发
- 刷新失败会执行 `logout()` 并清除本地 token
- ITOS 启动时通过 `Config::loadFromFile("config.json")` 读取配置
- 配置校验在 `cfg.validate()` 中完成

## 涉及文件

- `src/auth/token_manager.cpp` / `.h`
- `src/auth/auth_middleware.cpp` / `.h`
- `src/auth/auth_service.cpp` / `.h`
- `src/config/config_manager.cpp` / `.h`
- `src/main/itos_launch.cpp`

## 关键设计模式

- AuthService 使用 RAII 管理 token 生命周期
- Middleware 采用责任链模式
- Config 使用 Builder 模式

## 历史对话提炼

- 11-08 10:00: 用户问了 token 刷新位置 → AI 定位到 token_manager.cpp:142
- 11-08 11:30: 用户问了 ITOS 启动配置流程 → AI 梳理了 main() 初始化链
