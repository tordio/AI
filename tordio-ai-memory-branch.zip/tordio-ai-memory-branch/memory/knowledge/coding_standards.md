# 项目代码规范范例

> 这个文件告诉 AI 你的项目代码风格，让它生成符合规范的代码

## C++ 命名规范

- 类名: PascalCase (如 `AuthService`, `TokenManager`)
- 函数名: camelCase (如 `refreshToken()`, `validateInput()`)
- 成员变量: 后缀下划线 (如 `config_`, `token_manager_`)
- 常量: k 前缀 PascalCase (如 `kMaxRetries`)
- 宏: 全大写下划线 (如 `MAX_BUFFER_SIZE`)

## 项目结构约定

```
src/
├── main/          # 主程序入口
├── auth/          # 认证模块
├── network/       # 网络模块
├── utils/         # 工具函数
└── config/        # 配置管理
```

## 头文件引用规范

- 系统头文件用 `<>` : `#include <string>`
- 项目头文件用 `""` : `#include "auth/token_manager.h"`
- 头文件中使用 include guard : `#pragma once`

## 日志规范

- 使用项目日志宏，不用 printf
- 级别: LOG_DEBUG, LOG_INFO, LOG_WARN, LOG_ERROR
- 格式: `LOG_INFO("module_name", "message with {}", value);`

## 内存管理

- 优先使用智能指针 (`std::shared_ptr`, `std::unique_ptr`)
- 禁止裸 new/delete，用 RAII
- 不确定时参考项目现有代码

## 错误处理

- 不用异常，用 ErrorCode 枚举返回
- 函数签名: `ErrorCode doSomething(Args... args, Result* out_result)`
- 检查所有外部调用返回值
