# 搜索: C++20 coroutine 异步编程

**保存时间**: 2026-11-08 13:00:00

## 来源
https://en.cppreference.com/w/cpp/language/coroutines

## 内容

C++20 引入了协程支持，允许函数暂停和恢复执行，非常适合异步编程。

### 基本语法

```cpp
#include <coroutine>
#include <future>

// 一个返回 Task 的协程
Task<int> asyncCompute() {
    co_await std::suspend_always{};  // 暂停点
    co_return 42;                     // 返回值
}

// 等待协程完成
auto task = asyncCompute();
// ... 做其他事
int result = co_await task;  // 恢复协程并获取结果
```

### 关键概念

1. **co_await**: 暂停当前协程，等待另一个 awaitable
2. **co_yield**: 产生一个值并暂停（用于生成器）
3. **co_return**: 从协程返回值
4. **std::coroutine_handle**: 手动恢复协程的句柄

### 应用场景

- 异步 I/O（网络、文件）
- 延迟计算 / 惰性序列
- 状态机
- 事件驱动编程

## 在 ITOS 中的应用建议

如果 ITOS 需要异步网络请求，可以考虑用协程替代回调地狱：

```cpp
Task<HttpResponse> fetchUserData(int userId) {
    auto response = co_await httpClient.get(fmt::format("/users/{}", userId));
    co_return parseUser(response);
}
```
