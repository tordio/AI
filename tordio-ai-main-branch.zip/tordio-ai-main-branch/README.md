# Tordio AI - 个人代码助手

> 本地小模型 + 自动记忆 + 联网搜索 + 代码检索 = 无限上下文感

## 架构

- **基座模型**: Qwen2.5-Coder-1.5B-Q4 (本地运行)
- **记忆系统**: GitHub `memory` 分支 (Markdown)
- **代码检索**: ChromaDB 向量索引
- **联网搜索**: DuckDuckGo (Python)
- **运行环境**: Termux (Android) / Linux

## 语言支持

C++ / Java / Python / JavaScript / HTML / CSS

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置
cp config/config.yaml.example config/config.yaml
# 编辑 config.yaml 填入你的设置

# 3. 启动对话
python scripts/chat.py
```

## 目录结构

```
tordio-ai/
├── scripts/          # 所有核心脚本
├── config/           # 配置文件
├── memory/           # AI 记忆 (对话/摘要/知识)
├── index/            # 向量索引
├── projects/         # 同步的项目仓库
└── .github/          # 自动化工作流
```
